package com.android.calculator

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.pow

class MainActivity : AppCompatActivity() {
    private lateinit var num1EditText: EditText
    private lateinit var num2EditText: EditText
    private lateinit var num3EditText: EditText
    private lateinit var num4EditText: EditText
    private lateinit var resultNumber: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        num1EditText = findViewById(R.id.num1EditText)
        num2EditText = findViewById(R.id.num2EditText)
        num3EditText = findViewById(R.id.num3EditText)
        num4EditText = findViewById(R.id.num4EditText)
        resultNumber = findViewById(R.id.resultNumber)

        val minusButton: Button = findViewById(R.id.minusButton)
        minusButton.setOnClickListener { clearResult(it) }

        val bt_jurosreal: Button = findViewById(R.id.bt_jurosreal)
        bt_jurosreal.setOnClickListener{
            IrParaJurosReal()
        }
    }

    @SuppressLint("DefaultLocale")
    fun add(view: View) {
        val valorInicial: Double = num1EditText.text.toString().toDouble() // aplicação inicial
        val taxa = num2EditText.text.toString().toDouble() // taxa de juros mensal
        val prazo = num3EditText.text.toString().toInt() // prazo em meses
        val aportes = num4EditText.text.toString().toDouble() // aporte mensal fixo

        val taxaDecimal = taxa / 100
        val vfInicial: Double = valorInicial * Math.pow((1 + taxaDecimal), prazo.toDouble())
        val vfAportes: Double = aportes * ((Math.pow((1 + taxaDecimal), prazo.toDouble()) - 1) / taxaDecimal)
        val valorTotal: Double = vfInicial + vfAportes


        // Exibir o resultado
        resultNumber.text = String.format("%.2f", valorTotal) // Formatar para duas casas decimais
    }

    fun clearResult(view: View) {
        resultNumber.text = "0"
    }

    fun IrParaJurosReal(){
        val jurosReal = Intent(this, JurosReal::class.java)
        startActivity(jurosReal)
    }
}
